TrinketMenu_Trinket0:SetFrameStrata("MEDIUM");
TrinketMenu_Trinket1:SetFrameStrata("MEDIUM");
TrinketMenu_Menu1:SetFrameStrata("MEDIUM");